'use strict';

angular.module('angularFlaskServices', ['ngResource']);
